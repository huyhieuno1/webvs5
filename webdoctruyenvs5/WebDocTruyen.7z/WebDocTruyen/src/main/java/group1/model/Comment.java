package group1.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="COMMENT")
public class Comment {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String fullName;
	private String comment;
	private String date;
	@ManyToOne(cascade = CascadeType.ALL)
	private Truyen truyen;
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public Truyen getTruyen() {
		return truyen;
	}
	public void setTruyen(Truyen truyen) {
		this.truyen = truyen;
	}
	public Comment(String fullName, String comment, String date, Truyen truyen) {
		super();
		this.fullName = fullName;
		this.comment = comment;
		this.date = date;
		this.truyen = truyen;
	}
	public Comment() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
}
