package group1.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="RATE")
public class Rate {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private int rate;
	@ManyToOne(cascade = CascadeType.ALL)
	private Truyen truyen;
	private int number;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getRate() {
		return rate;
	}
	public void setRate(int rate) {
		this.rate = rate;
	}
	public Truyen getTruyen() {
		return truyen;
	}
	public void setTruyen(Truyen truyen) {
		this.truyen = truyen;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public Rate(int id, int rate, Truyen truyen, int number) {
		super();
		this.id = id;
		this.rate = rate;
		this.truyen = truyen;
		this.number = number;
	}
	public Rate() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
