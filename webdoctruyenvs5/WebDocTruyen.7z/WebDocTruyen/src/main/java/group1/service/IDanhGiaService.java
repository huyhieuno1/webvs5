package group1.service;

import group1.model.Rate;

public interface IDanhGiaService {

	void save(Rate dg);
}
