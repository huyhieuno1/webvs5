package group1.service;

import group1.model.TacGia;

public interface ITacGiaService {

	TacGia tgia();
	
}
